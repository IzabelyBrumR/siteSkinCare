<body>
    <style>
        footer {
            background-color: #bdf0e979;
            padding: 25px;
        }
        footer {
            background-color: #bdf0e979;
            color: black;
            padding: 32px;
        }
        footer a {
            color: #bdf0e979;
        }
        footer a:hover {
            color: #777;
            text-decoration: none;
        }
    </style>
    <footer class="text-center" style="background-color: #3596ea;">
        <a class="up-arrow" href="" data-toggle="tooltip" title="TO TOP">
            <span class="glyphicon glyphicon-chevron-up"></span>
        </a><br><br>
        <p>Voltar ao topo</p> 
    </footer>
</body>

